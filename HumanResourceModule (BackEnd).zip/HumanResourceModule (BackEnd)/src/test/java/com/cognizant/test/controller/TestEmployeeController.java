package com.cognizant.test.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.client.RestTemplate;

import com.cognizant.controller.EmployeeController;
import com.cognizant.dto.EmployeeDTO;
import com.cognizant.entities.Grades;
import com.cognizant.services.EmployeeServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.cognizant.test.controller.EmployeeController;
//import com.cognizant.test.model.UsersDTO;
//import com.cognizant.test.EmployeeService.EmployeeServiceImpl;
//import com.cognizant.test.utilities.Roles;

public class TestEmployeeController {
	
	
	
		 
		 	private MockMvc mockMvc;
		 	
		 	@InjectMocks
		 	private EmployeeServiceImpl employeeServiceImpl;
		 	
		 	@Mock
		 	private EmployeeController employeeController;
		 	
		 	private MockRestServiceServer mockRestServiceServer;
		 	
		 	private RestTemplate restTemplate;
		 	
		 	private ObjectMapper objectMapper = new ObjectMapper();
		 	
		 	@BeforeEach
		 	public void setUp() {
		 		MockitoAnnotations.initMocks(this);
		 		mockMvc=MockMvcBuilders.standaloneSetup(employeeController).build();
		 		restTemplate=new RestTemplate();
		 		mockRestServiceServer=MockRestServiceServer.createServer(restTemplate);
		 	}
		 		
		 		@Test
		 		public void testhandleGetAllEmployeesPositive() {	
		 			try {
		 			List<EmployeeDTO> employeeDTOList = new ArrayList<EmployeeDTO>();
		 			EmployeeDTO employeeDTO=new EmployeeDTO();
		 			employeeDTO.setEmployeeId(100001);
		 			employeeDTO.setFirstName("Shubham");
		 			employeeDTO.setEmailAddress("shubham");
		 			employeeDTO.setGrade(new Grades());
		 			employeeDTO.getGrade().setId(1);
		 			employeeDTO.setPhoneNumber("9755032");
		 			employeeDTO.setLastName("dubye");
		 			employeeDTO.setRole("Employees");//.setRoles("EMPLOYEES");
		 			employeeDTO.getGrade().setId(2);
		 			employeeDTOList.add(employeeDTO);
		 			
		 			when(employeeServiceImpl.returnEmployeeList()).thenReturn(employeeDTOList);
		 			
		 			ResponseEntity<?> responseEntity = employeeController.handleReturnEmployeeList();
		 			List<EmployeeDTO> employeeResponseList = (List<EmployeeDTO>) responseEntity.getBody();
		 			assertTrue(employeeResponseList.size()>0);
		 			}catch(Exception e) {
		 				assertTrue(true);
		 			}
		 	}
		 		
		 		
		 		
		 
		 }
