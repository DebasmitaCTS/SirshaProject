package com.cognizant.test.repositories;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ContextConfiguration;

import com.cognizant.entities.Grades;
import com.cognizant.entities.GradesHistory;
import com.cognizant.entities.Users;
import com.cognizant.main.HumanResourceModuleApplication;
import com.cognizant.repositories.GradesHistoryRepository;

@DataJpaTest
@ContextConfiguration(classes = HumanResourceModuleApplication.class)
class TestGradesHistoryRepository {
	@Autowired
	private GradesHistoryRepository gradesHistoryRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		GradesHistory GH=new GradesHistory();
		GH.setId(1);
		GH.setAssignedOn(LocalDate.of(2022,1,1));
		Users U=new Users();
		U.setEmployeeId(101);
		U.setFirstName("John");
		U.setLastName("Doe");
		U.setPhoneNumber("1234567890");
		U.setEmailAddress("john.doe@example.com");
		U.setRole("Employee");
		Grades G=new Grades();
		G.setId(1);
		G.setName("Grade A");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		GH.setUser(U);
		GH.setGrade(G);
		entityManager.persist(GH);
		Iterable<GradesHistory> it=gradesHistoryRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<GradesHistory> it=gradesHistoryRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		GradesHistory GH=new GradesHistory();
		GH.setId(2);
		GH.setAssignedOn(LocalDate.of(2022,1,2));
		Users U=new Users();
		U.setEmployeeId(102);
		U.setFirstName("Jane");
		U.setLastName("Doe");
		U.setPhoneNumber("9876543210");
		U.setEmailAddress("jane.doe@example.com");
		U.setRole("Supervisor");
		Grades G=new Grades();
		G.setId(2);
		G.setName("Grade B");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		GH.setUser(U);
		GH.setGrade(G);
		entityManager.persist(GH);
		Optional<GradesHistory> gradesHistory=gradesHistoryRepository.findById(2);
		assertTrue(gradesHistory.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<GradesHistory> gradesHistory=gradesHistoryRepository.findById(2);
		assertTrue(!gradesHistory.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		GradesHistory GH=new GradesHistory();
		GH.setId(3);
		GH.setAssignedOn(LocalDate.of(2022,1,3));
		Users U=new Users();
		U.setEmployeeId(103);
		U.setFirstName("Alice");
		U.setLastName("Smith");
		U.setPhoneNumber("5555555555");
		U.setEmailAddress("alice.smith@example.com");
		U.setRole("Employee");
		Grades G=new Grades();
		G.setId(3);
		G.setName("Grade C");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		GH.setUser(U);
		GH.setGrade(G);
		gradesHistoryRepository.save(GH);
		Optional<GradesHistory> gradesHistory=gradesHistoryRepository.findById(3);
		assertTrue(gradesHistory.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		GradesHistory GH=new GradesHistory();
		GH.setId(3);
		GH.setAssignedOn(LocalDate.of(2022,1,3));
		Users U=new Users();
		U.setEmployeeId(103);
		U.setFirstName("Alice");
		U.setLastName("Smith");
		U.setPhoneNumber("5555555555");
		U.setEmailAddress("alice.smith@example.com");
		U.setRole("Employee");
		Grades G=new Grades();
		G.setId(3);
		G.setName("Grade C");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		GH.setUser(U);
		GH.setGrade(G);
		entityManager.persist(GH);
		gradesHistoryRepository.delete(GH);
		Optional<GradesHistory> gradesHistory=gradesHistoryRepository.findById(3);
		assertTrue(!gradesHistory.isPresent());
	}

}


