package com.cognizant.test.repositories;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cognizant.entities.Grades;
import com.cognizant.main.HumanResourceModuleApplication;
import com.cognizant.repositories.GradesRepository;

@DataJpaTest
@ContextConfiguration(classes = HumanResourceModuleApplication.class)
class TestGradesRepository {
	@Autowired
	private GradesRepository gradesRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		Grades G=new Grades();
		G.setId(1);
		G.setName("Grade A");
		entityManager.persist(G);
		Iterable<Grades> it=gradesRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<Grades> it=gradesRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Grades G=new Grades();
		G.setId(2);
		G.setName("Grade B");
		entityManager.persist(G);
		Optional<Grades> grade=gradesRepository.findById(2);
		assertTrue(grade.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Grades> grade=gradesRepository.findById(2);
		assertTrue(!grade.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Grades G=new Grades();
		G.setId(3);
		G.setName("Grade C");
		gradesRepository.save(G);
		Optional<Grades> grade=gradesRepository.findById(3);
		assertTrue(grade.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		Grades G=new Grades();
		G.setId(3);
		G.setName("Grade C");
		entityManager.persist(G);
		gradesRepository.delete(G);
		Optional<Grades> grade=gradesRepository.findById(3);
		assertTrue(!grade.isPresent());
	}

}
