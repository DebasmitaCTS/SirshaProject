package com.cognizant.test.repositories;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.main.HumanResourceModuleApplication;

@SpringBootTest(classes=HumanResourceModuleApplication.class)
public class HumanResourceModuleTest {
	@Test
	public void contextLoads() {
		
	}
}
