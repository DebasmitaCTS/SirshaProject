package com.cognizant.test.repositories;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.cognizant.entities.Grades;
import com.cognizant.entities.Users;
import com.cognizant.main.HumanResourceModuleApplication;

import com.cognizant.repositories.GradesRepository;
import com.cognizant.repositories.UsersRepository;

@DataJpaTest
@ContextConfiguration(classes = HumanResourceModuleApplication.class)
class TestUsersRepository {
	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private TestEntityManager entityManager;
	@Test
	public void testFindAllPositive() {
		Users U=new Users();
		U.setEmployeeId(101);
		U.setFirstName("John");
		U.setLastName("Doe");
		U.setPhoneNumber("1234567890");
		U.setEmailAddress("john.doe@example.com");
		U.setRole("Employee");
		Grades G=new Grades();
		G.setId(1);
		G.setName("Grade A");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		Iterable<Users> it=usersRepository.findAll();
		assertTrue(it.iterator().hasNext());
	}
	@Test
	public void testFindAllNegative() {
		Iterable<Users> it=usersRepository.findAll();
		assertTrue(!it.iterator().hasNext());
	}
	
	
	@Test
	public void testFindByIdPositive() {
		Users U=new Users();
		U.setEmployeeId(102);
		U.setFirstName("Jane");
		U.setLastName("Doe");
		U.setPhoneNumber("9876543210");
		U.setEmailAddress("jane.doe@example.com");
		U.setRole("Supervisor");
		Grades G=new Grades();
		G.setId(2);
		G.setName("Grade B");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		Optional<Users> user=usersRepository.findById(102);
		assertTrue(user.isPresent());
	}
	
	@Test
	public void testFindByIdNegative() {
		Optional<Users> user=usersRepository.findById(2);
		assertTrue(!user.isPresent());
	}
	
	@Test
	public void testSavePositive() {
		Users U=new Users();
		U.setEmployeeId(103);
		U.setFirstName("Alice");
		U.setLastName("Smith");
		U.setPhoneNumber("5555555555");
		U.setEmailAddress("alice.smith@example.com");
		U.setRole("Employee");
		Grades G=new Grades();
		G.setId(3);
		G.setName("Grade C");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		usersRepository.save(U);
		Optional<Users> user=usersRepository.findById(103);
		assertTrue(user.isPresent());
	}
	
	@Test
	public void testDeletePositive() {
		Users U=new Users();
		U.setEmployeeId(103);
		U.setFirstName("Alice");
		U.setLastName("Smith");
		U.setPhoneNumber("5555555555");
		U.setEmailAddress("alice.smith@example.com");
		U.setRole("Employee");
		Grades G=new Grades();
		G.setId(3);
		G.setName("Grade C");
		entityManager.persist(G);
		U.setGrade(G);
		entityManager.persist(U);
		usersRepository.delete(U);
		Optional<Users> user=usersRepository.findById(3);
		assertTrue(!user.isPresent());
	}

}

