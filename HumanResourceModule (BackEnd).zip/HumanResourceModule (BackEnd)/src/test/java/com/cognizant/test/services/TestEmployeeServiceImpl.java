package com.cognizant.test.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.EmployeeDTO;
import com.cognizant.dto.GradeDTO;
import com.cognizant.entities.Grades;
import com.cognizant.entities.GradesHistory;
import com.cognizant.entities.Users;
import com.cognizant.exceptions.GradeUpdateRuleViolationException;
import com.cognizant.repositories.GradesHistoryRepository;
import com.cognizant.repositories.GradesRepository;
import com.cognizant.repositories.UsersRepository;
import com.cognizant.services.EmployeeServiceImpl;



public class TestEmployeeServiceImpl {
	
	@Mock
	private UsersRepository usersRepository;
	
	@Mock
	private GradesRepository gradesRepository;
	
	@Mock
	private GradesHistoryRepository gradesHistoryRepository;

	@InjectMocks
	EmployeeServiceImpl employeeServiceImpl;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testGetEmployeeByIdPositive() {
		// Mock data
		Users mockUsers = new Users();
		mockUsers.setEmployeeId(1001);
		mockUsers.setEmailAddress("shubham");
		mockUsers.setFirstName("shubham");
		mockUsers.setLastName("shubham");
		mockUsers.setPhoneNumber("9755033217");
		mockUsers.setRole("HR");
		
		Grades grades = new Grades();
		grades.setName("Good");
		grades.setId(1);
		
		mockUsers.setGrade(grades);
		
		Optional<Grades> optionalOfGrades=Optional.of(grades);
		
		when(gradesRepository.findById(1)).thenReturn(optionalOfGrades);
		
		Optional<Users> optionalOfUsers = Optional.of(mockUsers);
		when(usersRepository.findById(mockUsers.getEmployeeId())).thenReturn(optionalOfUsers);
 
		// Call the service method
		EmployeeDTO result= employeeServiceImpl.getEmployeeById(1001);
		assertNotNull(result);
		
	}
	
	@Test
	public void testGetEmployeeByIdNegaive() {
	
		Users mockUsers = new Users();
		mockUsers.setEmployeeId(1001);
		mockUsers.setEmailAddress("shubham");
		mockUsers.setFirstName("shubham");
		mockUsers.setLastName("shubham");
		mockUsers.setPhoneNumber("9755033217");
		mockUsers.setRole("HR");
		
		Optional<Users> optionalOfUsers = Optional.of(mockUsers);
		when(usersRepository.findById(mockUsers.getEmployeeId())).thenReturn(optionalOfUsers);
 
		// Call the service method
		EmployeeDTO result= employeeServiceImpl.getEmployeeById(1002);
		assertNull(result);
		
	}
 
	@Test
	public void testUpdateUsersGradePositive() throws GradeUpdateRuleViolationException {
		
		Users users = new Users();
		users.setEmployeeId(100102);
		users.setEmailAddress("shubham@cognizant.com");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("Employee");
		
		Grades grades1 = new Grades();
		grades1.setName("Good");
		grades1.setId(1);
		
		Grades grades2 = new Grades();
		grades2.setName("Good");
		grades2.setId(2);
		
		Optional<Grades> optionalOfGrades1=Optional.of(grades1);
		Optional<Grades> optionalOfGrades2=Optional.of(grades1);
		
		when(gradesRepository.findById(1)).thenReturn(optionalOfGrades1);
		when(gradesRepository.findById(2)).thenReturn(optionalOfGrades2);
		
		users.setGrade(grades1);
		
		Optional<Users> optionalUsers = Optional.of(users);
		
		when(usersRepository.findById(1001)).thenReturn(optionalUsers);
		
		
		EmployeeDTO EDTO=new EmployeeDTO();
		EDTO.setEmployeeId(100102);
		EDTO.setEmailAddress("shubham@cognizant.com");
		EDTO.setFirstName("shubham");
		EDTO.setLastName("shubham");
		EDTO.setPhoneNumber("9755033217");
		EDTO.setRole("Employee");
		
		Grades gu = new Grades();
		gu.setName("Good");
		gu.setId(3);
		
		EDTO.setGrade(gu);
		
		Users mockUsers=new ModelMapper().map(EDTO,Users.class);
		when(usersRepository.save(users)).thenReturn(mockUsers);
		
		String res= employeeServiceImpl.updateEmployeeGarde(EDTO);
		
		assertNotEquals("success", res);
		
		
	}
	
	@Test
	public void testUpdateUsersGradeNegative() throws GradeUpdateRuleViolationException {
		
		Users users = new Users();
		users.setEmployeeId(100102);
		users.setEmailAddress("shubham@cognizant.com");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("Employee");
		
		Grades g1 = new Grades();
		g1.setName("Good");
		g1.setId(1);
		
		Grades g2 = new Grades();
		g2.setName("Good");
		g2.setId(2);
		
		Optional<Grades> optionalOfGrades1=Optional.of(g1);
		
		Optional<Grades> optionalOfGrades2=Optional.of(g1);
		
		when(gradesRepository.findById(1)).thenReturn(optionalOfGrades1);
		when(gradesRepository.findById(2)).thenReturn(optionalOfGrades2);
		
		users.setGrade(g1);
		
		Optional<Users> optionalUsers = Optional.of(users);
		
		when(usersRepository.findById(100102)).thenReturn(optionalUsers);
		
		EmployeeDTO EDTO=new EmployeeDTO();
		EDTO.setEmployeeId(100102);
		EDTO.setEmailAddress("shubham@cognizant.com");
		EDTO.setFirstName("shubham");
		EDTO.setLastName("shubham");
		EDTO.setPhoneNumber("9755033217");
		EDTO.setRole("Employee");
		
		Grades gu = new Grades();
		gu.setId(2);
		
		EDTO.setGrade(gu);
		
		Users mockUsers=new ModelMapper().map(EDTO,Users.class);
		when(usersRepository.save(users)).thenReturn(mockUsers);
		
		String res= employeeServiceImpl.updateEmployeeGarde(EDTO);
		
		assertEquals("fail", res);
	}

	@Test
	public void testUpdateUsersGradeException() {
		try {
			Users users = new Users();
			users.setEmployeeId(100102);
			users.setEmailAddress("shubham@cognizant.com");
			users.setFirstName("shubham");
			users.setLastName("shubham");
			users.setPhoneNumber("9755033217");
			users.setRole("Employee");
			
			Grades grades1 = new Grades();
			grades1.setName("Good");
			grades1.setId(1);
			
			Grades grades2 = new Grades();
			grades2.setName("Good");
			grades2.setId(2);
			
			Optional<Grades> optionalOfGrades1=Optional.of(grades1);
			Optional<Grades> optionalOfGrades2=Optional.of(grades1);
			
			when(gradesRepository.findById(1)).thenReturn(optionalOfGrades1);
			when(gradesRepository.findById(2)).thenReturn(optionalOfGrades2);
			
			users.setGrade(grades1);
			
			Optional<Users> optionalUsers = Optional.of(users);
			
			when(usersRepository.findById(100102)).thenReturn(optionalUsers);
			
			EmployeeDTO EDTO=new EmployeeDTO();
			EDTO.setEmployeeId(100102);
			EDTO.setEmailAddress("shubham@cognizant.com");
			EDTO.setFirstName("shubham");
			EDTO.setLastName("shubham");
			EDTO.setPhoneNumber("9755033217");
			EDTO.setRole("Employee");
			
			Grades gu = new Grades();
			gu.setId(2);
			
			EDTO.setGrade(gu);
			
			Users mockUsers=new ModelMapper().map(EDTO,Users.class);
			String res = employeeServiceImpl.updateEmployeeGarde(EDTO);
			
		} catch(GradeUpdateRuleViolationException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testUpdateEmployeeGradesIfGradesIsLess() throws GradeUpdateRuleViolationException {
		Users users = new Users();
		users.setEmployeeId(1001);
		users.setEmailAddress("shubham");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("EMPLOYEES");
		
		Grades g1 = new Grades();
		g1.setName("Good");
		g1.setId(1);
		
		Grades g2 = new Grades();
		g2.setName("Good");
		g2.setId(2);
		
		Optional<Grades> optionalOfGrades1=Optional.of(g1);
		
		Optional<Grades> optionalOfGrades2=Optional.of(g1);
		
		when(gradesRepository.findById(1)).thenReturn(optionalOfGrades1);
		when(gradesRepository.findById(2)).thenReturn(optionalOfGrades2);
		
		users.setGrade(g1);
		
		Optional<Users> optionalUsers = Optional.of(users);
		
		when(usersRepository.findById(1001)).thenReturn(optionalUsers);
		
		EmployeeDTO EDTO=new EmployeeDTO();
		EDTO.setEmployeeId(100102);
		EDTO.setEmailAddress("shubham@cognizant.com");
		EDTO.setFirstName("shubham");
		EDTO.setLastName("shubham");
		EDTO.setPhoneNumber("9755033217");
		EDTO.setRole("Employee");
		
		Grades gu = new Grades();
		gu.setId(1);
		
		EDTO.setGrade(gu);
		
		Users mockUsers=new ModelMapper().map(EDTO,Users.class);
		
		when(usersRepository.save(users)).thenReturn(mockUsers);
		
		String res= employeeServiceImpl.updateEmployeeGarde(EDTO);
		
		assertEquals("fail", res);
	}
	
	@Test
	public void testUpdateEmployeeIfGradesNotPresent() throws GradeUpdateRuleViolationException {
		Users users = new Users();
		users.setEmployeeId(100102);
		users.setEmailAddress("shubham@cognizant.com");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("Employee");
		
		Optional<Users> optionalUsers = Optional.of(users);
		
		when(usersRepository.findById(1001)).thenReturn(optionalUsers);
		
		EmployeeDTO EDTO=new EmployeeDTO();
		EDTO.setEmployeeId(100102);
		EDTO.setEmailAddress("shubham@cognizant.com");
		EDTO.setFirstName("shubham");
		EDTO.setLastName("shubham");
		EDTO.setPhoneNumber("9755033217");
		EDTO.setRole("Employee");
		
		Grades gu = new Grades();
		gu.setId(2);
		
		EDTO.setGrade(gu);
		
		Users mockUsers=new ModelMapper().map(EDTO,Users.class);
		
		when(usersRepository.save(users)).thenReturn(mockUsers);
		
		String res= employeeServiceImpl.updateEmployeeGarde(EDTO);
		
		assertEquals("fail", res);
	}
	
	@Test
	public void testDeleteEmployeePositive() {
		
		int employeeIdToBeDeleted = 1001;
		
		Users users = new Users();
		users.setEmployeeId(1001);
		users.setEmailAddress("shubham");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("HR");
		
		Grades g = new Grades();
		g.setName("good");
		g.setId(1);
		
		users.setGrade(g);
		
		GradesHistory gh = new GradesHistory();
		gh.setAssignedOn(LocalDate.now());
		gh.setGrade(g);
		gh.setUser(users);
		gh.setId(1);
		
		Optional<Users> optionalOfUsers = Optional.of(users);
		Optional<GradesHistory> optionalOfGradesHistory = Optional.of(gh);
		when(usersRepository.findById(users.getEmployeeId())).thenReturn(optionalOfUsers);
		when(gradesHistoryRepository.findById(users.getEmployeeId())).thenReturn(optionalOfGradesHistory);		
		
		String result = employeeServiceImpl.deleteEmployee(employeeIdToBeDeleted);
		verify(usersRepository,times(1)).deleteById(1001);

		
		assertEquals("success",result);
		
	}
	
	@Test
	public void testDeleteEmployeeNegative() {
		
		int employeeIdToBeDeleted = 1002;
		
		Users users = new Users();
		users.setEmployeeId(1001);
		users.setEmailAddress("shubham");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("HR");

		Grades g = new Grades();
		g.setName("good");
		g.setId(1);
		
		users.setGrade(g);
		
		GradesHistory gh = new GradesHistory();
		gh.setAssignedOn(LocalDate.now());
		gh.setGrade(g);
		gh.setUser(users);
		gh.setId(1);
		
		Optional<Users> optionalOfUsers = Optional.of(users);
		Optional<GradesHistory> optionalOfGradesHistory = Optional.of(gh);
		when(usersRepository.findById(users.getEmployeeId())).thenReturn(optionalOfUsers);
		when(gradesHistoryRepository.findById(users.getEmployeeId())).thenReturn(optionalOfGradesHistory);		
		
		String result = employeeServiceImpl.deleteEmployee(employeeIdToBeDeleted);

		
		assertEquals("fail",result);
		
	}
	
	@Test
	public void testReturnEmployeeListPositive() {
		
		Users u1= new Users();
		u1.setEmailAddress("shubham@gmail.com");
		u1.setEmployeeId(1001);
		u1.setFirstName("shubham");
		u1.setLastName("dubey");
		u1.setPhoneNumber("9755033217");
		u1.setRole("EMPLOYEES");
		
		Grades g1 = new Grades();
		g1.setName("good");
		g1.setId(1);
		
		u1.setGrade(g1);
		
		Users u2 = new Users();
		u1.setEmailAddress("shubham@gmail.com");
		u1.setEmployeeId(1001);
		u1.setFirstName("shubham");
		u1.setLastName("dubey");
		u1.setPhoneNumber("9755033217");
		u1.setRole("EMPLOYEES");
		
		Grades g2 = new Grades();
		g2.setName("very good");
		g2.setId(2);
		
		u2.setGrade(g2);
		
		List<Users> ul = new ArrayList<Users>();
		ul.add(u2);
		ul.add(u1);
		
		Mockito.when(usersRepository.findAll()).thenReturn(ul);
		
		List<EmployeeDTO> users = employeeServiceImpl.returnEmployeeList();
		
		assertTrue(!users.isEmpty());
	}

	@Test
	public void testReturnEmployeeListNegative() {
		
		List<Users> usersList = new ArrayList<Users>();

		Mockito.when(usersRepository.findAll()).thenReturn(usersList);
		
		List<EmployeeDTO> userDto = employeeServiceImpl.returnEmployeeList();
		
		assertTrue(userDto.isEmpty());
	}
	
	@Test
	public void testReturnGradesListPositive() {

		
		Grades g1 = new Grades();
		g1.setName("good");
		g1.setId(1);
		
		
		Grades g2 = new Grades();
		g2.setName("very good");
		g2.setId(2);
		
		
		List<Grades> gl = new ArrayList<Grades>();
		gl.add(g1);
		gl.add(g2);
		
		Mockito.when(gradesRepository.findAll()).thenReturn(gl);
		
		List<GradeDTO> grades = employeeServiceImpl.returnGradesList();
		
		assertTrue(!grades.isEmpty());
	}

	@Test
	public void testReturnGradesListNegative() {
		
		List<Grades> gl = new ArrayList<Grades>();

		Mockito.when(gradesRepository.findAll()).thenReturn(gl);
		
		List<GradeDTO> grades = employeeServiceImpl.returnGradesList();
		
		assertTrue(grades.isEmpty());
		
	}
	
	@Test
	public void testPersistNewEmployeePositive()
	{
		Users users = new Users();
		users.setEmployeeId(100102);
		users.setEmailAddress("shubham@cognizant.com");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("Employee");
		
		Grades grades = new Grades();
		grades.setName("Good");
		grades.setId(1);
		
		Optional<Grades> optionalOfGrades=Optional.of(grades);
		
		when(gradesRepository.findById(1)).thenReturn(optionalOfGrades);
		
		users.setGrade(grades);

		when(usersRepository.save(any())).thenAnswer((invocation)-> {
				Users optionalUsers = new Users();
				optionalUsers.setEmployeeId(100102);
				optionalUsers.setEmailAddress("shubham@cognizant.com");
				optionalUsers.setFirstName("shubham");
				optionalUsers.setLastName("shubham");
				optionalUsers.setPhoneNumber("9755033217");
				optionalUsers.setRole("Employee");
				optionalUsers.setGrade(grades);
				return optionalUsers;
		});
				
		EmployeeDTO usersDto = new EmployeeDTO();
		usersDto.setEmployeeId(100102);
		usersDto.setEmailAddress("shubham@cognizant.com");
		usersDto.setFirstName("shubham");
		usersDto.setLastName("shubham");
		usersDto.setPhoneNumber("9755033217");
		usersDto.setRole("Employee");
		usersDto.setGrade(grades);
		
		String result = employeeServiceImpl.persistNewEmployees(usersDto);
		verify(usersRepository,times(1)).save(any());
		assertEquals("success", result);
		
	}
	

	@Test
	public void testPersistNewEmployeeNegative()
	{
		Users users = new Users();
		users.setEmployeeId(100102);
		users.setEmailAddress("shubham@cognizant.com");
		users.setFirstName("shubham");
		users.setLastName("shubham");
		users.setPhoneNumber("9755033217");
		users.setRole("Employee");
		
		Grades grades = new Grades();
		grades.setName("Good");
		grades.setId(1);
		
		Optional<Grades> optionalOfGrades=Optional.of(grades);
		
		when(gradesRepository.findById(1)).thenReturn(optionalOfGrades);
		
		users.setGrade(grades);
		
		Optional<Users> optionalUsers = Optional.of(users);
		
		when(usersRepository.findById(1001)).thenReturn(optionalUsers);
		
		EmployeeDTO usersDto = new EmployeeDTO();
		usersDto.setEmployeeId(100202);
		usersDto.setEmailAddress("shubham@cognizant.com");
		usersDto.setFirstName("shubham");
		usersDto.setLastName("shubham");
		usersDto.setPhoneNumber("9755033217");
		usersDto.setRole("Employee");
		usersDto.setGrade(grades);;
		
		String result = employeeServiceImpl.persistNewEmployees(usersDto);
		assertNotEquals("success", result);
		
	}
}

