INSERT INTO Grades(Id, Name)
VALUES
    (1, 'Grade A'),
    (2, 'Grade B'),
    (3, 'Grade C');


INSERT INTO Users(Employee_Id, First_Name, Last_Name, Phone_Number, Email_Address, Role, Current_Grade_Id)
VALUES
    (101, 'John', 'Doe', '1234567890', 'john.doe@example.com','Manager', 1),
    (102, 'Jane', 'Doe', '9876543210', 'jane.doe@example.com','Supervisor',  2),
    (103, 'Alice', 'Smith', '5555555555', 'alice.smith@example.com','Employee', 3);


INSERT INTO Grades_History(Id, Assigned_On, Employee_Id, Grade_Id)
VALUES
    (1, '2022-01-01', 101, 1),
    (2, '2022-01-02', 102, 2),
    (3, '2022-01-03', 103, 3);