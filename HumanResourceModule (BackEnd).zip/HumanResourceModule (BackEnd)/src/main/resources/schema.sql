CREATE TABLE Grades(
 
	Id INTEGER  ,
	Name VARCHAR(25)NOT NULL,
	Constraint PK1 Primary Key(Id)
);
 
CREATE TABLE Users(
	Employee_Id INTEGER ,
    First_Name VARCHAR(10)NOT NULL,
    Last_Name VARCHAR(10)NOT NULL,
    Phone_Number VARCHAR(10)NOT NULL,
    Email_Address VARCHAR(50)NOT NULL,
    Role VARCHAR(15)NOT NULL,
    Current_Grade_Id INTEGER NOT NULL,
  Constraint PK2  Primary Key(Employee_Id),
  Constraint FK1  foreign key(Current_Grade_Id) references Grades(Id)
);
 
CREATE TABLE Grades_History(
	Id INTEGER ,
        Assigned_On date NOT NULL,
	Employee_Id INTEGER NOT NULL,
        Grade_Id INTEGER NOT NULL,
	Constraint PK3 Primary Key(Id),
	Constraint FK2 foreign key (Employee_Id) references Users(Employee_Id),
	Constraint FK3 foreign key (Grade_Id) references Grades(Id)
);
