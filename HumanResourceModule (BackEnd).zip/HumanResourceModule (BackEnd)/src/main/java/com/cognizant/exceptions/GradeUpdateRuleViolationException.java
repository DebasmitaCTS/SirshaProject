package com.cognizant.exceptions;

public class GradeUpdateRuleViolationException extends RuntimeException{
	
	public GradeUpdateRuleViolationException(String message) {
		super(message);
	}
}
