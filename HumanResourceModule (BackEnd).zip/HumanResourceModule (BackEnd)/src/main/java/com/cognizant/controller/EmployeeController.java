package com.cognizant.controller;

//import org.junit.jupiter.api.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.dto.EmployeeDTO;
import com.cognizant.dto.GradeDTO;
import com.cognizant.exceptions.GradeUpdateRuleViolationException;
import com.cognizant.services.EmployeeService;
import com.cognizant.services.EmployeeServiceImpl;
import java.util.List;

import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("api")
@Tag(name="Hr Management",description="Hr Management REST API")
public class EmployeeController {
	
	
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping("grades")
	public ResponseEntity<?> handleReturnGradesList(){
		List<GradeDTO> responseList = employeeService.returnGradesList();
		ResponseEntity<List<GradeDTO>> responseEntity = null;
		if(!responseList.isEmpty()) {
			responseEntity = new ResponseEntity<List<GradeDTO>>(responseList, HttpStatus.OK);
		}
		else {
			responseEntity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
	
	
	@PostMapping("employees")
	public ResponseEntity<?> handleAddEmployee(@RequestBody EmployeeDTO EDTO){
		String result=employeeService.persistNewEmployees(EDTO);
		if(result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.CREATED);
		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}	
		
	}


	
	
	
	
	@PutMapping("/{id}/update")
		public ResponseEntity<?> updateEmployeeGrade(@PathVariable("id")Integer employeeId,@RequestBody EmployeeDTO employeeDTO)
		{
			String result = employeeService.updateEmployeeGarde(employeeDTO);
			if(result.equals("success")) {
				return new ResponseEntity<>(HttpStatus.OK);    //update booking
			}else {
				return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
			}
		}
	
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<?> deleteEmployee(@PathVariable("id")Integer employeeId)
	{
		String result = employeeService.deleteEmployee(employeeId);
		if(result.equals("success")) {
			return new ResponseEntity<>(HttpStatus.OK);    //update booking
		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@GetMapping("employees")
	public ResponseEntity<?> getEmployeeById(){
		List<EmployeeDTO> responseList = employeeService.returnEmployeeList();
		ResponseEntity<List<EmployeeDTO>> responseEntity = null;
		if(!responseList.isEmpty()) {
			responseEntity = new ResponseEntity<List<EmployeeDTO>>(responseList, HttpStatus.OK);
		}
		else {
			responseEntity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}
		

	@GetMapping("employees/{id}")
	public ResponseEntity<?> handleReturnEmployeeList(){
		List<EmployeeDTO> responseList = employeeService.returnEmployeeList();
		ResponseEntity<List<EmployeeDTO>> responseEntity = null;
		if(!responseList.isEmpty()) {
			responseEntity = new ResponseEntity<List<EmployeeDTO>>(responseList, HttpStatus.OK);
		}
		else {
			responseEntity=new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return responseEntity;
	}	
	
	
}


	 

