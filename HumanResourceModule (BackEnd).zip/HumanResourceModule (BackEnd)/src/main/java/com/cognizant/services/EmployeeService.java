package com.cognizant.services;

import java.util.*;

import com.cognizant.dto.EmployeeDTO;
import com.cognizant.dto.GradeDTO;
import com.cognizant.exceptions.GradeUpdateRuleViolationException;


public interface EmployeeService {
	
	List<EmployeeDTO> returnEmployeeList();
	String persistNewEmployees(EmployeeDTO employeeDTO);
	String deleteEmployee(int id);
	String updateEmployeeGarde(EmployeeDTO employeeDTO) throws GradeUpdateRuleViolationException;
	EmployeeDTO getEmployeeById(int id);
	List<GradeDTO> returnGradesList();
	
	
}
