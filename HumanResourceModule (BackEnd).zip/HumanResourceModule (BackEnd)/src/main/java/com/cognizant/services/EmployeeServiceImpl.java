package com.cognizant.services;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dto.EmployeeDTO;
import com.cognizant.dto.GradeDTO;
import com.cognizant.entities.Grades;
import com.cognizant.entities.GradesHistory;
import com.cognizant.entities.Users;
import com.cognizant.exceptions.GradeUpdateRuleViolationException;
import com.cognizant.repositories.GradesHistoryRepository;
import com.cognizant.repositories.GradesRepository;
import com.cognizant.repositories.UsersRepository;
import com.cognizant.utilities.EmployeeValidation;

import jakarta.transaction.Transactional;

@Service

public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	private UsersRepository usersRepository;
	@Autowired
	private GradesRepository gradesRepository;
	@Autowired
	private GradesHistoryRepository gradesHistoryRepository;
	
	ModelMapper modelMapper=new ModelMapper();
	
	@Override
	public String persistNewEmployees(EmployeeDTO employeeDTO) {
		
		EmployeeValidation empValidation=new EmployeeValidation(usersRepository);
		empValidation.validateEmployee(employeeDTO);
		
		Users users=modelMapper.map(employeeDTO, Users.class);
		Optional<Grades> grades = gradesRepository.findById(employeeDTO.getGrade().getId());

		if(grades.isEmpty()) 
		{
			return "fail";
		}
		
		users.setGrade(grades.get());
				
		GradesHistory gradesHistory = new GradesHistory();
		gradesHistory.setId(employeeDTO.getGrade().getId());
		gradesHistory.setAssignedOn(LocalDate.now());		
		gradesHistory.setGrade(grades.get());
		gradesHistory.setUser(users);
		Users usersCreated=usersRepository.save(users);
		System.out.println("userCreate8d:"+usersCreated);
		if(usersCreated!=null) {
			gradesHistoryRepository.save(gradesHistory);
			return "success";
		}
		else {
		return "fail";}
	}

	@Override
	public List<EmployeeDTO> returnEmployeeList() {
	
		Iterable<Users> usersList=usersRepository.findAll();
		List<EmployeeDTO> employeeDTOList=new ArrayList<EmployeeDTO>();
		
		for(Users users:usersList) {
			
			EmployeeDTO employeeDTO =modelMapper.map(users, EmployeeDTO.class);
			
			employeeDTOList.add(employeeDTO);
		}
		return employeeDTOList;
				
	}
	
	@Override
	public String updateEmployeeGarde(EmployeeDTO employeeDTO) {
		
		EmployeeValidation empValidation=new EmployeeValidation(usersRepository);
		empValidation.validateEmployee(employeeDTO);
	
		Optional<Users> optionalOfUsers=usersRepository.findById(employeeDTO.getEmployeeId());
		if(optionalOfUsers.isEmpty()) return "fail";
		Users usersUpdated=null;
		Optional<Grades> optionalGrades = gradesRepository.findById(employeeDTO.getGrade().getId());	
		if(optionalGrades.isEmpty()) return "fail";
		Grades grades = optionalGrades.get();
		
		if(grades.getId() < employeeDTO.getGrade().getId()) return "fail";
		
		Iterable<GradesHistory> gradesHistory = gradesHistoryRepository.findAll();
		List<GradesHistory> gradesHsitoryList = new ArrayList<>();
		System.out.println(gradesHsitoryList.size());
		List<LocalDate> DateList = new ArrayList<>();
		for(GradesHistory g : gradesHistory) {
			if(g.getGrade().getId() == employeeDTO.getEmployeeId()) {
				gradesHsitoryList.add(g);
				DateList.add(g.getAssignedOn());
			}
		}
		
		if(gradesHsitoryList.size() == 1) {
			long yearsDifference = ChronoUnit.YEARS.between(gradesHsitoryList.get(0).getAssignedOn(), LocalDate.now());
			
		if(yearsDifference < 2) {
				throw new GradeUpdateRuleViolationException("Years must be more than 2 years");
			}
		}
		
		for(GradesHistory g : gradesHsitoryList) {
			
			if(ChronoUnit.DAYS.between(g.getAssignedOn(), LocalDate.now()) < 365) {
				return "fail";
			}
			
		}		
		
		if(optionalOfUsers.isPresent()) {
	    	Users users =optionalOfUsers.get();
	    	users.setGrade(grades);
	    	
		usersUpdated=usersRepository.save(users);
		}
		if(usersUpdated!=null)
			{
//				GradesHistory gHistory = new GradesHistory();
//				gHistory.setAssignedOn(LocalDate.now());		
//				gHistory.setGrade(grades);
//				gHistory.setUser(usersRepository.findById(employeeDTO.getEmployeeId()).get());
//				gradesHistoryRepository.save(gHistory);
				Grades g=new Grades();
				g.setId(grades.getId());
				g.setName(grades.getName());
				gradesRepository.save(g);
				return "success";
			}
		
		return "fail";
			
	}
	
	@Override
	public EmployeeDTO getEmployeeById(int id) {
		Optional<Users> optionalOfUsers=usersRepository.findById(id);
	
	    if(optionalOfUsers.isPresent()) {
	    	Users users = optionalOfUsers.get();
	    	EmployeeDTO employeeDTO=modelMapper.map(users,EmployeeDTO.class);
	    
			return employeeDTO;
	    }
	    else {
	    	return null;
	    }
	   
	}
	
	@Override
	public String deleteEmployee(int id) {
		
		Optional<Users> users = usersRepository.findById(id);
		if(users.isPresent())
		{
			Iterable<GradesHistory> gradesHistoryList = gradesHistoryRepository.findAll();
			for(GradesHistory gradesHistory : gradesHistoryList) {
				if(gradesHistory.getUser().getEmployeeId() == id) {
					gradesHistoryRepository.deleteById(gradesHistory.getId());
				}
			}
			usersRepository.deleteById(id);
			return "success";
		}
		else
		{
			return "fail";
		}
	}
	
	@Override
	public List<GradeDTO> returnGradesList() {
	
		Iterable<Grades> gradeList=gradesRepository.findAll();
		List<GradeDTO> gradeDTOList=new ArrayList<GradeDTO>();
		for(Grades grade:gradeList) {
			GradeDTO gradeDTO = new GradeDTO();
			gradeDTO.setId(grade.getId());
			gradeDTO.setName(grade.getName());
			gradeDTOList.add(gradeDTO);
		}
		return gradeDTOList;
		
	}

}
