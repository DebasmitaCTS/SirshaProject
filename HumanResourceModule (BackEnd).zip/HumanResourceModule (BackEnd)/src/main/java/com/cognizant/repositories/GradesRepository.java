package com.cognizant.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.entities.Grades;

@Repository
public interface GradesRepository extends CrudRepository<Grades,Integer> {

	
}
