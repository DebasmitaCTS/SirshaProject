package com.cognizant.dto;

import java.util.Date;

import org.hibernate.validator.constraints.Length;

import com.cognizant.entities.Grades;

import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;




@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {
	private int employeeId;
	
	@Length(max=15)
	private String firstName;
	
	@Length(max=10)
	private String lastName;
	
	@Length(min=10,max=10)
	private String phoneNumber;
	
	@Length(max=50)
	private String emailAddress;
	
	@Length(max=15)
	@Pattern(regexp="^(Employee|HR|TravelDeskExe)$")
	private String role;
	
	private Grades grade;
}
	
