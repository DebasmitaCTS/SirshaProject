package com.cognizant.utilities;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;

import com.cognizant.dto.EmployeeDTO;

import com.cognizant.repositories.UsersRepository;

import jakarta.validation.*;

public class EmployeeValidation {
	@Autowired
	private UsersRepository usersRepository;
	
	private Validator validator=Validation.buildDefaultValidatorFactory().getValidator();

	public EmployeeValidation(UsersRepository usersRepository) {
		this.usersRepository = usersRepository;
	}
	
	public void validateEmployee(EmployeeDTO EDTO) {
		Set<ConstraintViolation<EmployeeDTO>> violations=validator.validate(EDTO);
		
		if(!violations.isEmpty()) {
			throw new ConstraintViolationException(violations);
		}
		
		if((String.valueOf(EDTO.getEmployeeId())).length()!=6) {
			throw new IllegalArgumentException("Employee ID must be 6 digits long");
		}
		
		if(!EDTO.getEmailAddress().endsWith("@cognizant.com")) {
			throw new IllegalArgumentException("Email address should always have @cognizant.com");
		}
		
	
		if(EDTO.getRole().equals("xtw3")) {
			EDTO.getGrade().setName("Grade-1");;
		} 
	}
}
