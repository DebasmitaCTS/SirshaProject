package com.cognizant.entities;

import org.hibernate.validator.constraints.Length;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Pattern;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;



@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Users")
public class Users {
	
	@Id
	@Column(name="Employee_Id")
	private int employeeId;
	
	@Column(name="First_Name")
	private String firstName;
	
	@Column(name="Last_Name")
	private String lastName;
	
	@Column(name="Phone_Number")
	private String phoneNumber;
	
	@Column(name="Email_Address")
	private String emailAddress;
	
	@Column(name="Role")
	@Pattern(regexp="^(Employee|HR|TravelDeskExe)$")
	private String role;
	
	@ManyToOne
	@JoinColumn(name="Current_Grade_Id",referencedColumnName="Id")
	private Grades grade;

}


