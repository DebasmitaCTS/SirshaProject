package com.cognizant.entities;

import org.hibernate.validator.constraints.Length;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;



@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Grades")
public class Grades {

	@Id
	@Column(name="Id")
	private int id;
	
	@Column(name="Name")
	@Length(max=25)
	private String name;
	
}
