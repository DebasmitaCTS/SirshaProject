package com.cognizant.entities;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;



@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Grades_History")
public class GradesHistory {
    
	@Id
	@Column(name="Id")
	private int id;
	
	@Column(name="Assigned_On")
	@Temporal(TemporalType.DATE)
	private LocalDate assignedOn;
	
	@ManyToOne
	@JoinColumn(name="Employee_Id",referencedColumnName="Employee_Id")
	private Users user;
	
	@ManyToOne
	@JoinColumn(name="Grade_Id",referencedColumnName="Id")
    private Grades grade;

	
}
