export class Users{
    employeeId !: number;
    firstName !: string;
    lastName !: string;
    phoneNumber !: string;
    emailAddress !: string;
    role !: string;
    grade_id !: number;
}