export class Grades{
    identification : number;
    fullName : string;
}