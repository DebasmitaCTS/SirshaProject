export class AuthenticateUsers{
    userName:string;
    passWord:string;
    roles:string;
}