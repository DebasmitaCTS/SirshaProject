  import { HttpClient, HttpErrorResponse } from '@angular/common/http';
  import { Injectable } from '@angular/core';
  import { AuthenticateUsers } from '../models/authenticate';
  import { firstValueFrom, catchError, throwError } from 'rxjs';
  
  @Injectable({
    providedIn: 'root'
  })
  export class AuthenticateUsersService {

    constructor(private http:HttpClient) { 
      this.invalidCredentials = false;
    }
    authenticatedUrl : string = "http://localhost:8090/api/authenticate";
    authentiCatedUser : AuthenticateUsers;
    authentiCatedUserBacked : AuthenticateUsers;
    authenticated : boolean;
    invalidCredentials : boolean = false;
    errorMEssage : string = '';

    getAuthenticatedUser(user:AuthenticateUsers){
      return firstValueFrom(this.http.post<AuthenticateUsers>(this.authenticatedUrl,user).pipe(
        catchError(this.handleError)
      ));
    }
    
    private handleError(error: HttpErrorResponse) {
      return throwError(() => new Error("invalid credentials"));
    }

    async authenticate(userName, passWord){
      this.authentiCatedUser = new AuthenticateUsers();
      this.authentiCatedUser.userName = userName;
      this.authentiCatedUser.passWord = passWord;

    this.authentiCatedUserBacked = await this.getAuthenticatedUser(this.authentiCatedUser);

    if(this.authentiCatedUser.userName === this.authentiCatedUserBacked.userName && this.authentiCatedUser.passWord === this.authentiCatedUserBacked.passWord){
      this.authenticated = true;
      sessionStorage.setItem('username',this.authentiCatedUser.userName);
    }
    else{
      this.authenticated = false;
    }
    return this.authenticated;
  }
    isUserLoggedIn(){
      let username = sessionStorage.getItem('username');
      return !(username === null);
    }

    logOut(){
      sessionStorage.removeItem('username');
    }

  }
