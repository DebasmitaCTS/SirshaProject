import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthenticateUsersService } from '../authenticate-users.service';
import { AppComponent } from '../app.component';
import { AuthenticateUsers } from '../../models/authenticate';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  invalidCredentials : boolean = false;
  authenticated : string;
  authenticatedUser : AuthenticateUsers;
  authenticatedBackedUser : AuthenticateUsers;
  show = true;
  constructor(private router : Router, public authenticateUsersService:AuthenticateUsersService){}
  message : string;
  loginForm : FormGroup;

  ngOnInit() : void{
    this.router.navigate(['login']);
    this.loginForm = new FormGroup(
      {
        userName : new FormControl('',[Validators.required]),
        password : new FormControl('',[Validators.required]),
      }
    )
  }

  authenticateUser(){
    return this.authenticateUsersService.authenticate(this.loginForm.get('userName').value, this.loginForm.get('password').value);
  }
  async checkLogin(){
    this.show = false;
    let valid : boolean = await this.authenticateUser();
    console.log(valid);
   if(valid){
    this.router.navigate(['home']);
   }
   else{
    
   }
   }
}
